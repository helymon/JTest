﻿using SimpleTcp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ServerApplication
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SimpleTcpServer simpleTcpServer;
        private void btnStart_Click(object sender, EventArgs e)
        {
            simpleTcpServer.Start();
            txtInfo.Text += $"Starting... {Environment.NewLine}";
            btnStart.Enabled = false;
            btnSend.Enabled = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnSend.Enabled = false;
            simpleTcpServer = new SimpleTcpServer(txtIp.Text);
            simpleTcpServer.Events.ClientConnected += Events_ClientConnected;
            simpleTcpServer.Events.ClientDisconnected += Events_ClientDisconnected;
            simpleTcpServer.Events.DataReceived += Events_DataReceived;
        }

        private void Events_DataReceived(object sender, DataReceivedEventArgs e)
        {

            try
            {
                this.Invoke((MethodInvoker)delegate
                {
                  

                    string s = Encoding.UTF8.GetString(e.Data);
                    string[] subs = s.Split('|');
                    
                    if (subs.Length == 2)
                    { 
                        if(!isbinary(subs[0])) { SendMessageToClient(" Corrupt data"); return; }
                        if (!isbinary(subs[1])) { SendMessageToClient(" Corrupt data"); return; }

                        UpdateLineCount(e.IpPort, subs[0], subs[1]);
                        clientIp = e.IpPort;
                        txtInfo.Text += $"{e.IpPort}: Current : {subs[0]}{Environment.NewLine}";
                        txtInfo.Text += $"{e.IpPort}: Voltage : {subs[1]}{Environment.NewLine}";
                        SendMessageToClient(" successfully received the data");
                    }
                    else
                    {
                        SendMessageToClient(" Corrupt data");
                    }
                });
            }
            catch (Exception ex)
            {
                SendMessageToClient(" error occurred while receiving  data");
            }
        }

        private void Events_ClientDisconnected(object sender, ClientDisconnectedEventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
            {
                txtInfo.Text += $"{e.IpPort} disconnected. {Environment.NewLine}";
                clientIp = "";
            });
        }

        string clientIp = "";
        private void Events_ClientConnected(object sender, ClientConnectedEventArgs e)
        {


            this.Invoke((MethodInvoker)delegate
            {
                clientIp = e.IpPort;
                txtInfo.Text += $"{e.IpPort} connected. {Environment.NewLine}";
            });



        }


        public void SendMessageToClient(string message)
        {
            if (simpleTcpServer.IsListening)
            {
                if (clientIp != "")
                {
                    simpleTcpServer.Send(clientIp, message);
                    txtInfo.Text += $"Server : {message} {Environment.NewLine}";
                    txtMessage.Text = string.Empty;
                }
            }

        }


        private void btnSend_Click(object sender, EventArgs e)
        {


            if (simpleTcpServer.IsListening)
            {
                if (!string.IsNullOrEmpty(txtMessage.Text) && clientIp != "")
                {
                    simpleTcpServer.Send(clientIp, txtMessage.Text);
                    txtInfo.Text += $"Server : {txtMessage.Text} {Environment.NewLine}";
                    txtMessage.Text = string.Empty;
                }
            }
        }

        public static bool UpdateLineCount(string clintIp, string current, string voltage)
        {
            try
            {
                string connectionString = ConfigurationManager.ConnectionStrings["tempdbEntities"].ToString();
                SqlConnection con = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "insert into datainfo values('" + clintIp + "','" + current + "','" + voltage + "',getdate())";
                cmd.Connection = con;


                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();




                return true;
            }
            catch (Exception oException)
            {
                MessageBox.Show(oException.Message);
            }
            return false;
        }
        static bool isbinary(string s)
        {
            foreach (var c in s)
                if (c != '0' && c != '1')
                {
                    return false;
                }
            return true;
        }

    }
}
