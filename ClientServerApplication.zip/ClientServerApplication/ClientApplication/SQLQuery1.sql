﻿CREATE TABLE [dbo].[DataInfo]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [ClientIp] NVARCHAR(50) NULL, 
    [Current] NVARCHAR(50) NULL, 
    [voltage] NVARCHAR(50) NULL, 
    [MessageTime] DATETIME NULL 
)

drop table [DataInfo]

delete from  [DataInfo]
select * from [DataInfo]